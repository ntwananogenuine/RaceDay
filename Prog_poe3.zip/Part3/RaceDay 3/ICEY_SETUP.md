# RaceDay — Icey's ready-to-configure package

## Visual Studio (recommended for lecturer)

**The only external credential required for Azure image uploads is Icey's own Azure Storage connection string.** Visual Studio also needs .NET 8 and SQL Server Express LocalDB (usually installed via the ASP.NET / data workload). The API uses the standard `(localdb)\MSSQLLocalDB` instance and creates the database/tables automatically via `EnsureCreated` on first launch. No database script should be necessary on a fresh machine.

1. Extract the ZIP. Open `part2/RaceDay.sln` in Visual Studio.
2. In `part2/raceday_api/appsettings.json`, set `AzureBlobStorage:ConnectionString` to **his** Azure Storage account connection string. `ContainerName` is `raceday-images`; it will be created automatically as a private container on first successful upload. **Do not commit the real key to GitHub.** A safer alternative is right click the API project > Manage User Secrets and add `{"AzureBlobStorage":{"ConnectionString":"..."}}` there.
3. Run the API's **http** launch profile (port 5080); verify `http://localhost:5080/swagger` opens.
4. Open `part3/raceday_mvc` in Visual Studio as a project, run its **http** profile (port 5090), and open `http://localhost:5090`.
5. Register an organiser, create an event, upload a banner from Manage Events/Edit, and check that the banner appears on the event list. Upload a profile picture from Profile. Confirm files exist in Azure container `raceday-images`.

If LocalDB is missing, install SQL Server Express LocalDB or adjust `ConnectionStrings:DefaultConnection` to a reachable SQL Server instance. The same DB name, `RaceDayDB`, is used by the project.

## Docker Compose (alternative, needs Docker Desktop)

From the root, copy `.env.example` to `.env`, put his Azure connection string in `AZURE_BLOB_CONNECTION_STRING`, then run `docker compose up --build`. Open web `http://localhost:5090`, API Swagger is disabled in Production; API runs at `http://localhost:5080`. The SQL Server container creates its own database automatically. Port 14333 is reserved for optional host SQL troubleshooting. The example SA password is strictly for local development; change it before nonlocal use.

## Architecture / preserved work

Icey's original namespaces, API routes, MVC controllers/views, sessions, event/category/enrolment/results logic, tests, and CI are preserved. Azure uploads/downloads use his existing API and the MVC image proxy, not the lecturer's account. The original Part 2 tests and MVC .NET 8 project remain in place. Improvements: default LocalDB instance, safer replacement/cleanup of Azure image uploads, matching image signatures to content types, API Dockerfile, full docker compose with SQL/API/MVC, and CI build checks for both images.

## Verification caveat

The package was structurally inspected and configuration/ZIP files validated. A complete .NET build, unit tests, Visual Studio runtime test, Azure live upload, and Docker run have **not** been executed in this environment. Run the included CI workflow and end-to-end test before submission. External requirements are Visual Studio/.NET 8, a working SQL Server LocalDB (or Docker), Internet to restore NuGet packages, and an Azure account if testing storage.
